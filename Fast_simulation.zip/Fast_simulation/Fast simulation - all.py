# -*- coding: utf-8 -*-
"""
Éditeur de Spyder

Ceci est un script temporaire.
"""
import time
from numpy.random import *
from numpy import *
from matplotlib.pyplot import *
from math import *
from mpl_toolkits.mplot3d import Axes3D
from scipy.optimize import curve_fit
start_time = time.time()

lx = [3, 5, 5, 5]
lx1=3
lx2=2 
lz = 6
θF = 48*2*pi/360 # Construction angle

# Matrix of radiator length for each train
L_rad = [[63.4, 57.8, 52.2, 46.5], [59.1, 53.5, 47.9, 42.3], [52.9, 47.3, 41.7, 36.0], [46.7, 41.0, 35.4, 29.8]]
# Matrix of light guide length for each train
L_lg = [70.3, 65.2, 60.1, 55.0] 

n_air = 1
# Length of trajectoires for each option, with fast simulation
L1 = []
L2 = []
L3 = []
L3_edge_effect = []
L = []
# Length of trajectoires for each option, with Geant4
L1_geant = []  
L2_geant = [] 
L3_geant = [] 
L_geant = []
L3_edge_effect_geant = []
θ_ch = []
λ2 = []
Track = []
Sensor = []
Option = []

start_time = time.time()

Track = []
track = open("file-train2_50000.txt","r") # Open file of tracks
for line in track:
    Z=line.split(' ')
    Track.append([float(i) for i in Z])
track.close()
Size = len(Track)

α_t = 18*2*pi/360 # Angle of taper
angle = 0 # Angle between photon beam and cut edge

counter = 0
count = 0 # Counter of number of photons detected 
count1 = 0 # Counter of number of photons detected per option
count2 = 0
count3 = 0
count_mysterious=0
count_error = 0
N = 50000 # Number of tracks

t = 2 # Train (1, 2, 3 or 4) 
# Computation for each photon track
if (N!=0):
    for r in range(N):
        b = int(Track[r][2])-30 # Bar (1, 2, 3 or 4)
        xA_i = Track[r][6] # Coordinates of vertex A extracted from the file
        yA_i = abs(Track[r][5])+lz/tan(θF)*(b-1)
        zA_i = Track[r][7]+lz*(b-1)
        StepLength = zA_i/sin(θF)  # length between the side of radiator and vertex point A      
        θch=float(Track[r][4]) # Cherenkov angle
        θ_ch.append(θch)
        λ = -600*log((θch-0.809040)*9/(0.882864-0.809040)+1)**(1/2)+1100 # Wavelenght of photon
        n_silica = 1/cos(θch) # refraction index
        θc = arcsin(n_air/n_silica) # critical angle
        if -pi/2<Track[r][3]<pi: # ϕ angle, determined from the file
            ϕ = Track[r][3]-pi/2
        else:
            ϕ = 3*pi/2+Track[r][3]    
        λ2.append(ϕ) 
        δ = arcsin(sin(θch)*cos(ϕ)) # Projection angles
        α = arcsin(tan(δ)*tan(ϕ))+angle
        α_abs = abs(α)
        δ_abs = abs(δ)
        option = 0
        option3 = False
        length=0
        bounds=0
        taper = False
        edge_effect = False
        other_bar = False
        condition = False
        number = 0
                
        if (α>=0): 
            xA=xA_i
            yA=yA_i
            zA=zA_i
            α1=abs(θF-α_abs)
            condition = True
        else:
            l=StepLength+(yA_i-zA_i/tan(θF))*(cos(θF)+sin(θF)/tan(α_abs))  
            if l<b*lz/sin(θF): 
                yA = l*cos(θF) # Coordinates of the new initial point A'
                zA = l*sin(θF)
                xA = xA_i+abs(yA-yA_i)*tan(δ)*sin(θF)/sin(α_abs)
                length=sqrt((xA-xA_i)**2+(yA-yA_i)**2+(zA-zA_i)**2) # length [AA'] to add at the end
                option3 = True
                bounds=bounds+1 
                α1=abs(θF-α_abs)
                condition = True
            elif l>b*lz/sin(θF): 
                if cos(θc)>sin(θF+α_abs)*cos(δ_abs):
                    if α_abs<pi/2-θF:
                        xA=xA_i
                        yA=yA_i
                        zA=zA_i 
                        α1=θF+α_abs
                        condition = True
                    elif α_abs>pi/2-θF: 
                        print("ok")
                        xA = xA_i
                        zA = rand()*lz+lz*(b-1) # We choose a random point on the cut edge
                        yA = tan(pi/2-θF)*zA+2
                        length = 2*lz
                        option3=True
                        bounds=bounds+2
                        cond1=False
                        δ_abs = pi/2 
                else:
                    if b*lz/sin(θF)<l<4*lz/sin(θF):
                        edge_effect = True
                        b = int(l/(lz/sin(θF)))+1
                        yA = l*cos(θF) # Coordinates of the new initial point A'
                        zA = l*sin(θF)
                        xA = xA_i+abs(yA-yA_i)*tan(δ)*sin(θF)/sin(α_abs)
                        length=sqrt((xA-xA_i)**2+(yA-yA_i)**2+(zA-zA_i)**2)
                        option3=True   
                        bounds=bounds+1 
                        α1 = abs(θF-α_abs)
                        condition = True
            
        if condition:
            # conditions of total reflection
            cond0 = cos(θc)>sin(α1)*cos(δ_abs) # plan 0 of the radiator
            cond1 = cos(θc)>sin(δ_abs)  # plan 1 of the radiator
            cond2 = cos(θc)>cos(α1)*cos(δ_abs)  # plan 2 of the light guide
            cond3 = cos(θc)>sin(α_abs)*cos(δ_abs) # Cut edge (plan 3) 
        
        # Determination of the option (1, 2 or 3)
        if (condition and cond0 and cond1): 
            yA = yA-lz/tan(θF)*(b-1)
            zA = zA-lz*(b-1)
            δ1 = arctan(tan(δ)/cos(α1)) 
            if (δ1<0):
                δ1_abs = abs(δ1)
                if (xA/tan(δ1_abs)+yA > L_rad[t-1][b-1]-lx[t-1]):
                    option=1
                else:
                    d = (L_rad[t-1][b-1]-lx[t-1]-yA)*tan(δ1)+xA
                    int_d = int(d/lx[t-1])
                    d2 = lx[t-1]*tan(δ1)
                    if int_d%2==0:
                        if d+d2 > int_d*lx[t-1]-lx[t-1]:
                            option = 1
                            if t==1:
                                d3 = (lx1+lx2/tan(α_t))*tan(δ1)
                                dlim = int_d*lx[t-1]-lx1-lx2
                                if d+d3 < dlim:
                                    taper=True
                        else:
                            option = 2
                            yC = abs(int_d*lx[t-1]-lx[t-1]-xA)/tan(δ1_abs)+yA
                            if t==1:
                                d3 = (lx1+lx2)*tan(δ1)
                                dlim = int_d*lx[t-1]-lx1-lx2/tan(α_t)
                                if d+d3 > dlim:
                                    taper=True                                
                    else:
                        if (δ1_abs<pi/4):
                            option = 1
                        else:
                            option = 0  
                
            else:
                if ((lx[t-1]-xA)/tan(δ1)+yA>L_rad[t-1][b-1]):
                    option=1
                elif ((lx[t-1]-xA)/tan(δ1)+yA>L_rad[t-1][b-1]-lx[t-1]):
                    option=2 
                    taper=True
                else:
                    d = (L_rad[t-1][b-1]-lx[t-1]-yA)*tan(δ1)-(lx[t-1]-xA)
                    int_d = int(d/lx[t-1])
                    d2 = lx[t-1]*tan(δ1)
                    if int_d%2==0:
                        if d+d2 < int_d*lx[t-1]+lx[t-1]:
                            option = 1
                            if t==1:
                                d3 = (lx1+lx2/tan(α_t))*tan(δ1)
                                dlim = int_d*lx[t-1]+lx1+lx2
                                if d+d3 > dlim:
                                    taper=True
                        else:
                            option = 2
                            yC = (lx1-xA+int_d*lx[t-1]+lx[t-1])/tan(δ1)+yA
                            if t==1:
                                d3 = (lx1+lx2)*tan(δ1)
                                dlim = int_d*lx[t-1]+lx1+lx2/tan(α_t)
                                if d+d3 < dlim:
                                    taper=True                      
                    else:
                        if (δ1<pi/4):
                            option = 1
                        else:
                            option = 0  
        
        Labs = 1300*(1-exp(-λ/180))
        µabs = 1/Labs # Attenuation coefficient
        
        # length of photon trajectory
        if option==1:
            δ2 = abs(δ1)
            δ3 = abs(δ)
            α2 = α1
            if taper==True: # In the case where the train has taper (train1)
                δ2 = abs(δ2-2*α_t)
                δ3 = abs(δ3-2*arctan(cos(α2)*tan(α_t)))            
            bounds = bounds + int((L_rad[t-1][b-1]-yA-lx[t-1])*(tan(α1)/lz+tan(δ1)/lx[t-1])+L_lg[t-1]*(tan(α2)/lz+tan(δ2)/5)) # Number of bounds on the sides of the detector
            if (option3==False):
                #Calculation of length from vertex point to the photomultiplier
                l1 = (L_rad[t-1][b-1]-yA)/(cos(δ)*cos(α1))+L_lg[t-1]/(cos(α2)*cos(δ3))
                pabs = 1-exp(-µabs*l1) # Prabability of absorption
                x = rand()
                # Conditions of attenuation
                if (x<0.9 and x<1-pabs and x<0.99**bounds): 
                    if (Track[r][9]!=0):
                        L1.append(l1)
                        L1_geant.append(Track[r][9])
                    count1 = count1+1
                else:
                    option=0
            else:
                l3 = (L_rad[t-1][b-1]-yA)/(cos(δ)*cos(α1))+L_lg[t-1]/(cos(α2)*cos(δ3))+length
                pabs = 1-exp(-µabs*l3)
                x = rand()
                if (cond3 and x<0.9 and x<1-pabs and x<0.99**bounds): 
                    if (Track[r][9]!=0):
                        L3.append(l3)                
                        L3_geant.append(Track[r][9]) 
                        if (edge_effect):
                            L3_edge_effect.append(l3)
                            L3_edge_effect_geant.append(Track[r][9])
                    count3=count3+1
                else:
                    option=0  
                
        if (cond2 and option==2):
            δ2 = pi/2-abs(δ1)
            δ3 = arcsin(cos(δ)*cos(α1))
            α2 = arctan(tan(α1)*tan(δ2))
            if taper==True:
                δ2 = abs(δ2-2*α_t)
                δ3 = abs(δ3-2*arctan(cos(α2)*tan(α_t)))
            bounds = bounds + int((L_rad[t-1][b-1]-yA-lx[t-1])*(tan(α1)/lz+tan(δ1)/lx[t-1])+L_lg[t-1]*(tan(α2)/lz+tan(δ2)/5))
            if (option3==False):
                l2 = (yC-yA)/(cos(δ)*cos(α1))+L_lg[t-1]/(cos(α2)*cos(δ3))+3
                pabs = 1-exp(-µabs*l2)
                x = rand()
                if (cond2 and x<1-pabs and x<0.99**bounds): 
                    if (Track[r][9]!=0):
                        L2.append(l2)
                        L2_geant.append(Track[r][9])
                    count2 = count2+1
                else:
                    option=0
            else:     
                l3 = (yC-yA)/(cos(δ)*cos(α1))+L_lg[t-1]/(cos(α2)*cos(δ3))+length
                pabs = 1-exp(-µabs*l3)
                x=rand()
                if (cond2 and cond3 and x<1-pabs and x<0.99**bounds):
                    if (Track[r][9]!=0):
                        L3.append(l3)                
                        L3_geant.append(Track[r][9])   
                        if (edge_effect):
                            L3_edge_effect.append(l3)
                            L3_edge_effect_geant.append(Track[r][9])
                    count3=count3+1
                else:
                    option=0
    
        Option.append(option) 

print("Time execution : %s seconds ---" % (time.time() - start_time))

count = count1+count2+count3 # Number of tracks detected in the PMT

# Histograms of fast simulation and Geant4 lengths 
figure()
hist(L1_geant, color='white', edgecolor = 'red', range=(90,400), bins=500)
title('Option 1 - Geant4')
figure()
hist(L1, color='white', edgecolor = 'blue', range=(90,400), bins=500)
title('Option 1')
xlabel("Length (mm)")
ylabel("Number of tracks")

figure()
hist(L2_geant, color='white', edgecolor = 'red', range=(90,400), bins=500)
title('Option 2 - Geant4')
figure()
hist(L2, color='white', edgecolor = 'blue', range=(90,400), bins=500)
title('Option 2')
xlabel("Length (mm)")
ylabel("Number of tracks")

figure()
hist(L3_geant, color='white', edgecolor = 'red', range=(90,400), bins=500)
title('Option 3 - Geant4')
figure()
hist(L3, color='white', edgecolor = 'blue', range=(90,400), bins=500)
title('Option 3')
xlabel("Length (mm)")
ylabel("Number of tracks")

figure()
hist(L1_geant+L2_geant, color='white', edgecolor = 'red', range=(90,400), bins=500)
hist(L1+L2, color='white', edgecolor = 'blue', range=(90,400), bins=500)
title('Options 1 and 2')
xlabel("Length (mm)")
ylabel("Number of tracks")

# Histograms of differences between fast simulation and Geant4
diffL1 = zeros(size(L1))
for i in range(size(L1)):
    diffL1[i] = L1[i]-L1_geant[i]
diffL2 = zeros(size(L2))
for i in range(size(L2)):
    diffL2[i] = L2[i]-L2_geant[i]
diffL3 = zeros(size(L3))
for i in range(size(L3)):
    diffL3[i] = L3[i]-L3_geant[i]
L = L1+L2+L3
L_geant = L1_geant+L2_geant+L3_geant
diffL = zeros(size(L))
for i in range(size(L)):
    diffL[i] = L[i]-L_geant[i]
L1_L2 = L1+L2
L1_L2_geant = L1_geant+L2_geant
diffL1_L2 = zeros(size(L1_L2))
for i in range(size(L1_L2)):
    diffL1_L2[i] = L1_L2[i]-L1_L2_geant[i]
    
figure()
hist(diffL1,  color='white', edgecolor = 'green', range=(-20, 20), bins=500)
title('Option 1')
xlabel("Length (fast simulation) - length (Geant4) (mm)")
ylabel("Number of tracks")
figure()
hist(diffL2,  color='white', edgecolor = 'green', range=(-20, 20), bins=500)
title('Option 2')
xlabel("Length (fast simulation) - length (Geant4) (mm)")
ylabel("Number of tracks")
figure()
hist(diffL3, color='white', edgecolor = 'green', range=(-20, 20), bins=500)
title('Option 3')
xlabel("Length (fast simulation) - length (Geant4) (mm)")
ylabel("Number of tracks")


figure()
hist(L3_edge_effect, color='white', edgecolor = 'blue', range=(90,400), bins=500)
title('Option 3 - cutting edge effect')
xlabel("Length (mm)")
ylabel("Number of edge effect tracks")

figure()
hist(L3_edge_effect_geant, color='white', edgecolor = 'blue', range=(90,400), bins=500)
title('Option 3 - cutting edge effect - Geant4')
xlabel("Length (mm)")
ylabel("Number of edge effect tracks")

Diff_edge_effect = zeros(size(L3_edge_effect))
for i in range(size(L3_edge_effect)):
    Diff_edge_effect[i] = L3_edge_effect[i]-L3_edge_effect_geant[i]
    
figure()
hist(Diff_edge_effect, color='white', edgecolor = 'green', range=(-20, 20), bins=500)
title('Option 3 - cutting edge effect')
xlabel("Length (fast simulation) - length (Geant4) (mm)")
ylabel("Number of tracks")
